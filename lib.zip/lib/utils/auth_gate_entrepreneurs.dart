import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../Entrepreneurs/EntrepreneurHome.dart';
import '../Entrepreneurs/EntrepreneurLogin.dart';









void main() {
  runApp(new MaterialApp(
    home: new AuthGateEntrepreneurs(),
  ));
}


class AuthGateEntrepreneurs extends StatelessWidget {
  const AuthGateEntrepreneurs({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context,snapshot){
          if(!snapshot.hasData) {
            return EntrepreneurLogin();
          }
          return EntrepreneurHome();
        }
    );
  }
}