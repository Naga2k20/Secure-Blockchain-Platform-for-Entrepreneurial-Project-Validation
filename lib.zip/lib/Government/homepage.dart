import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class DashboardPage extends StatefulWidget {

  final String? name;
  final String? email;
  final String? mobile;
  final String? department;
  final String? designation;
  final String? district;
  final String? okey;

  const DashboardPage({
    Key? key,
    this.name,
    this.email,
    this.mobile,
    this.designation,
    this.department,
    this.district,
    this.okey,
  }) : super(key: key);


  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Welcome to the Government Officials Portal',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.indigo.shade700,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'This portal allows government officials to manage reports, review public policies, and ensure smooth governance.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.indigo.shade900,
                ),
              ),
            ),
            SizedBox(height: 20),
            CarouselSlider(
              options: CarouselOptions(height: 200.0, autoPlay: true, enlargeCenterPage: true),
              items: [
                'assets/images/govoff1.jpg',
                'assets/images/govoff2.jpg',
                'assets/images/govoff3.jpg',
                'assets/images/govoff4.jpg'
              ].map((i) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: BoxDecoration(color: Colors.indigo.shade100),
                      child: Image.asset(i, fit: BoxFit.cover),
                    );
                  },
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.bar_chart),
              label: Text('Inspections'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo.shade700),
              onPressed: () {},
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.policy),
              label: Text('My Reports'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo.shade700),
              onPressed: () {},
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.assignment), label: 'Inspections'),
          BottomNavigationBarItem(icon: Icon(Icons.policy), label: 'My Reports'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.indigo.shade700,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
